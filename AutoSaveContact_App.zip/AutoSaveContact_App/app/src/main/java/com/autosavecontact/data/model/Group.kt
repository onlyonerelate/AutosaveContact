// ─────────────────────────────────────────────
// Group.kt
// ─────────────────────────────────────────────
package com.autosavecontact.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "table_groups")
data class Group(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val groupName: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
