// ─────────────────────────────────────────────
// AppDatabase.kt
// ─────────────────────────────────────────────
package com.autosavecontact.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.autosavecontact.data.model.Contact
import com.autosavecontact.data.model.Group

@Database(
    entities = [Contact::class, Group::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun contactDao(): ContactDao
    abstract fun groupDao(): GroupDao

    companion object {
        private const val DB_NAME = "autosave_contact.db"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
