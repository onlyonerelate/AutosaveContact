// ─────────────────────────────────────────────
// Contact.kt
// ─────────────────────────────────────────────
package com.autosavecontact.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Mirrors the original DB schema:
 * CREATE TABLE IF NOT EXISTS table_contacts(
 *   _id INTEGER PRIMARY KEY,
 *   _contacts_name TEXT,
 *   _contacts_no TEXT,
 *   _contacts_grp_name TEXT
 * )
 */
@Entity(tableName = "table_contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String = "",
    val phoneNumber: String = "",
    val groupName: String = "",
    val callType: String = "",       // INCOMING / OUTGOING / MISSED
    val savedAt: Long = System.currentTimeMillis()
)
