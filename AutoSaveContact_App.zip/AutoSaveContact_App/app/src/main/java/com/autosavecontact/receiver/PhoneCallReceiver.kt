// ─────────────────────────────────────────────
// PhoneCallReceiver.kt
// ─────────────────────────────────────────────
package com.autosavecontact.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.telephony.TelephonyManager
import android.util.Log
import com.autosavecontact.data.db.AppDatabase
import com.autosavecontact.data.model.Contact
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Listens for incoming and outgoing calls.
 * When a call ends (or a new outgoing call starts), checks if the number
 * is already in the device contacts. If NOT → auto-saves to local DB.
 */
class PhoneCallReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "PhoneCallReceiver"
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var lastIncomingNumber = ""
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {

            // ── Outgoing call ──────────────────────────────
            Intent.ACTION_NEW_OUTGOING_CALL -> {
                val number = intent.getStringExtra(Intent.EXTRA_PHONE_NUMBER) ?: return
                Log.d(TAG, "Outgoing call to: $number")
                checkAndSave(context, number, "OUTGOING")
            }

            // ── Incoming call state changes ────────────────
            TelephonyManager.ACTION_PHONE_STATE_CHANGED -> {
                val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE)
                val number = intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""

                when (state) {
                    TelephonyManager.EXTRA_STATE_RINGING -> {
                        lastIncomingNumber = number
                        lastState = TelephonyManager.CALL_STATE_RINGING
                        Log.d(TAG, "Incoming call from: $number")
                    }
                    TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                        lastState = TelephonyManager.CALL_STATE_OFFHOOK
                    }
                    TelephonyManager.EXTRA_STATE_IDLE -> {
                        // Call ended — save if it was an answered incoming call
                        if (lastState == TelephonyManager.CALL_STATE_OFFHOOK
                            && lastIncomingNumber.isNotEmpty()
                        ) {
                            checkAndSave(context, lastIncomingNumber, "INCOMING")
                        } else if (lastState == TelephonyManager.CALL_STATE_RINGING
                            && lastIncomingNumber.isNotEmpty()
                        ) {
                            checkAndSave(context, lastIncomingNumber, "MISSED")
                        }
                        lastState = TelephonyManager.CALL_STATE_IDLE
                        lastIncomingNumber = ""
                    }
                }
            }
        }
    }

    /**
     * Checks if [number] already exists in the device's contact book.
     * If not found → inserts into local Room DB.
     */
    private fun checkAndSave(context: Context, number: String, callType: String) {
        if (number.isBlank()) return

        CoroutineScope(Dispatchers.IO).launch {
            // 1. Check device contacts
            val existsInDevice = isNumberInDeviceContacts(context, number)
            if (existsInDevice) {
                Log.d(TAG, "Number $number already in device contacts — skipping")
                return@launch
            }

            // 2. Check local DB (avoid duplicates)
            val db = AppDatabase.getInstance(context)
            val existing = db.contactDao().getContactByNumber(number)
            if (existing != null) {
                Log.d(TAG, "Number $number already in local DB — skipping")
                return@launch
            }

            // 3. Save to local DB
            val contact = Contact(
                phoneNumber = number,
                name = number,          // Name unknown until user edits
                callType = callType,
                groupName = ""
            )
            val inserted = db.contactDao().insert(contact)
            Log.d(TAG, "Auto-saved new contact: $number (id=$inserted, type=$callType)")
        }
    }

    /**
     * Returns true if [number] is found in the Android system Contacts.
     */
    private fun isNumberInDeviceContacts(context: Context, number: String): Boolean {
        return try {
            val uri = android.net.Uri.withAppendedPath(
                ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                android.net.Uri.encode(number)
            )
            val cursor = context.contentResolver.query(
                uri,
                arrayOf(ContactsContract.PhoneLookup._ID),
                null, null, null
            )
            val found = (cursor?.count ?: 0) > 0
            cursor?.close()
            found
        } catch (e: Exception) {
            Log.e(TAG, "Error checking device contacts", e)
            false
        }
    }
}
