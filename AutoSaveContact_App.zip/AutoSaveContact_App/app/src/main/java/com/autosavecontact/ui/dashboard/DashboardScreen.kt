// ─────────────────────────────────────────────
// DashboardScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.autosavecontact.Routes
import com.autosavecontact.ui.contacts.ContactsViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: ContactsViewModel,
    onNavigate: (String) -> Unit
) {
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val contacts by viewModel.contacts.collectAsState()
    val groups by viewModel.groups.collectAsState()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            NavDrawerContent(
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    onNavigate(route)
                }
            )
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("AutoSave Contact", fontWeight = FontWeight.Bold) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = Color.White,
                        navigationIconContentColor = Color.White
                    )
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {

                // ── Stats Row ─────────────────────────────────
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(
                        label = "Saved Contacts",
                        value = contacts.size.toString(),
                        icon = Icons.Default.Person,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        label = "Groups",
                        value = groups.size.toString(),
                        icon = Icons.Default.Group,
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ── Call type breakdown ───────────────────────
                val incoming = contacts.count { it.callType == "INCOMING" }
                val outgoing = contacts.count { it.callType == "OUTGOING" }
                val missed   = contacts.count { it.callType == "MISSED" }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MiniStatChip("Incoming", incoming, Color(0xFF4CAF50), Modifier.weight(1f))
                    MiniStatChip("Outgoing", outgoing, Color(0xFF2196F3), Modifier.weight(1f))
                    MiniStatChip("Missed",   missed,   Color(0xFFF44336), Modifier.weight(1f))
                }

                Divider()

                // ── Quick Action Buttons ──────────────────────
                Text(
                    "Quick Actions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                QuickActionGrid(onNavigate = onNavigate)
            }
        }
    }
}

// ── Stat Card ─────────────────────────────────────────────────────────
@Composable
fun StatCard(
    label: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ── Mini stat chip ────────────────────────────────────────────────────
@Composable
fun MiniStatChip(label: String, count: Int, color: Color, modifier: Modifier = Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(8.dp)) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count.toString(), fontWeight = FontWeight.Bold, color = color, fontSize = 18.sp)
            Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ── Quick Action Grid ─────────────────────────────────────────────────
@Composable
fun QuickActionGrid(onNavigate: (String) -> Unit) {
    val actions = listOf(
        Triple("Contacts", Icons.Default.Contacts, Routes.CONTACTS),
        Triple("Groups",   Icons.Default.Group,    Routes.GROUPS),
        Triple("Export",   Icons.Default.Share,    Routes.EXPORT),
        Triple("Settings", Icons.Default.Settings, Routes.SETTINGS),
        Triple("Help",     Icons.Default.Help,     Routes.HELP),
        Triple("About",    Icons.Default.Info,     Routes.ABOUT),
    )

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        actions.chunked(3).forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { (label, icon, route) ->
                    ActionButton(
                        label = label,
                        icon = icon,
                        onClick = { onNavigate(route) },
                        modifier = Modifier.weight(1f)
                    )
                }
                // Fill empty slots if row has < 3
                repeat(3 - row.size) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun ActionButton(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .aspectRatio(1f)
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                icon,
                contentDescription = label,
                modifier = Modifier.size(32.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(4.dp))
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ── Navigation Drawer ─────────────────────────────────────────────────
@Composable
fun NavDrawerContent(onNavigate: (String) -> Unit) {
    ModalDrawerSheet(modifier = Modifier.width(280.dp)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp)
                .background(MaterialTheme.colorScheme.primary),
            contentAlignment = Alignment.BottomStart
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Icon(
                    Icons.Default.ContactPhone,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "AutoSave Contact",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text("Auto-save your callers", color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
            }
        }

        Spacer(Modifier.height(8.dp))

        DrawerItem(Icons.Default.Home, "Home", Routes.DASHBOARD, onNavigate)
        DrawerItem(Icons.Default.Contacts, "Contacts", Routes.CONTACTS, onNavigate)
        DrawerItem(Icons.Default.Group, "Groups", Routes.GROUPS, onNavigate)
        DrawerItem(Icons.Default.Share, "Export", Routes.EXPORT, onNavigate)
        Divider(modifier = Modifier.padding(vertical = 8.dp))
        DrawerItem(Icons.Default.Settings, "Settings", Routes.SETTINGS, onNavigate)
        DrawerItem(Icons.Default.Help, "Help", Routes.HELP, onNavigate)
        DrawerItem(Icons.Default.Info, "About", Routes.ABOUT, onNavigate)
    }
}

@Composable
fun DrawerItem(icon: ImageVector, label: String, route: String, onNavigate: (String) -> Unit) {
    NavigationDrawerItem(
        icon = { Icon(icon, contentDescription = null) },
        label = { Text(label) },
        selected = false,
        onClick = { onNavigate(route) },
        modifier = Modifier.padding(horizontal = 8.dp)
    )
}
