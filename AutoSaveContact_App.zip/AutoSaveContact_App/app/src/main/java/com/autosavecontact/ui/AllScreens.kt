// ─────────────────────────────────────────────
// GroupsScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.groups

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.autosavecontact.data.model.Group
import com.autosavecontact.ui.contacts.ContactsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroupsScreen(viewModel: ContactsViewModel, onBack: () -> Unit) {
    val groups by viewModel.groups.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newGroupName by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Groups") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Add Group")
            }
        }
    ) { padding ->
        if (groups.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Group, null, modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline)
                    Spacer(Modifier.height(12.dp))
                    Text("No groups yet", color = MaterialTheme.colorScheme.outline)
                    Text("Tap + to create a group", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(groups, key = { it.id }) { group ->
                    GroupItem(group = group, onDelete = { viewModel.deleteGroup(group) })
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false; newGroupName = "" },
            title = { Text("Add Group") },
            text = {
                OutlinedTextField(
                    value = newGroupName,
                    onValueChange = { newGroupName = it },
                    label = { Text("Group name (min 3 chars)") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newGroupName.length >= 3) {
                        viewModel.addGroup(newGroupName.trim())
                        newGroupName = ""
                        showAddDialog = false
                    }
                }) { Text("Add") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false; newGroupName = "" }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun GroupItem(group: Group, onDelete: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Group, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Text(group.groupName, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium)
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}


// ─────────────────────────────────────────────
// ExportScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.export

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.autosavecontact.ui.contacts.ContactsViewModel
import java.io.File

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportScreen(viewModel: ContactsViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val contacts by viewModel.contacts.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Export Contacts") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))
            Icon(Icons.Default.Share, null, modifier = Modifier.size(72.dp),
                tint = MaterialTheme.colorScheme.primary)
            Text("${contacts.size} contacts ready to export",
                style = MaterialTheme.typography.titleMedium)

            Spacer(Modifier.height(8.dp))

            // Export CSV button
            Button(
                onClick = {
                    if (contacts.isEmpty()) {
                        Toast.makeText(context, "No contacts to export", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val csv = viewModel.exportToCSV(contacts)
                    val file = File(context.cacheDir, "autosave_contacts.csv")
                    file.writeText(csv)
                    val uri = FileProvider.getUriForFile(
                        context, "${context.packageName}.provider", file
                    )
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(intent, "Export CSV"))
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.TableChart, null)
                Spacer(Modifier.width(8.dp))
                Text("Export as CSV")
            }

            OutlinedButton(
                onClick = {
                    Toast.makeText(context, "VCF export coming soon", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.ContactPage, null)
                Spacer(Modifier.width(8.dp))
                Text("Export as VCF (vCard)")
            }
        }
    }
}


// ─────────────────────────────────────────────
// SettingsScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.settings

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.edit

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val prefs = context.getSharedPreferences("autosave_prefs", Context.MODE_PRIVATE)

    var autoSaveEnabled by remember { mutableStateOf(prefs.getBoolean("auto_save", true)) }
    var saveIncoming by remember { mutableStateOf(prefs.getBoolean("save_incoming", true)) }
    var saveOutgoing by remember { mutableStateOf(prefs.getBoolean("save_outgoing", true)) }
    var saveMissed by remember { mutableStateOf(prefs.getBoolean("save_missed", true)) }
    var showNotifications by remember { mutableStateOf(prefs.getBoolean("notifications", true)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {

            SettingsToggle(
                title = "Auto-Save Contacts",
                subtitle = "Automatically save unknown callers",
                icon = Icons.Default.AutoAwesome,
                checked = autoSaveEnabled,
                onCheckedChange = {
                    autoSaveEnabled = it
                    prefs.edit { putBoolean("auto_save", it) }
                }
            )
            Divider()
            SettingsToggle(
                title = "Save Incoming Calls",
                subtitle = "Save numbers from incoming calls",
                icon = Icons.Default.CallReceived,
                checked = saveIncoming,
                onCheckedChange = { saveIncoming = it; prefs.edit { putBoolean("save_incoming", it) } }
            )
            Divider()
            SettingsToggle(
                title = "Save Outgoing Calls",
                subtitle = "Save numbers you dial",
                icon = Icons.Default.CallMade,
                checked = saveOutgoing,
                onCheckedChange = { saveOutgoing = it; prefs.edit { putBoolean("save_outgoing", it) } }
            )
            Divider()
            SettingsToggle(
                title = "Save Missed Calls",
                subtitle = "Save numbers from missed calls",
                icon = Icons.Default.CallMissed,
                checked = saveMissed,
                onCheckedChange = { saveMissed = it; prefs.edit { putBoolean("save_missed", it) } }
            )
            Divider()
            SettingsToggle(
                title = "Show Notifications",
                subtitle = "Notify when a contact is saved",
                icon = Icons.Default.Notifications,
                checked = showNotifications,
                onCheckedChange = { showNotifications = it; prefs.edit { putBoolean("notifications", it) } }
            )
        }
    }
}

@Composable
fun SettingsToggle(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(modifier = Modifier.weight(1f)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.bodyLarge)
                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline)
            }
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}


// ─────────────────────────────────────────────
// HelpScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.help

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Help") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            HelpItem("How does auto-save work?",
                "When you receive or make a call, the app checks if the number is already in your contacts. If not, it automatically saves it to the app's list.")
            HelpItem("How do I save a contact to my phone?",
                "Go to Contacts, tap the three dots (⋮) next to any contact, then tap 'Save to Device'.")
            HelpItem("How do I create a group?",
                "Go to Groups and tap the + button. Group names must be at least 3 characters.")
            HelpItem("How do I export contacts?",
                "Go to Export and choose CSV format. You can share the file via WhatsApp, email, or any other app.")
            HelpItem("Why isn't it saving contacts?",
                "Make sure you have granted Phone and Contacts permissions. Go to Settings → Apps → AutoSave Contact → Permissions.")
        }
    }
}

@Composable
fun HelpItem(question: String, answer: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(question, fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(6.dp))
            Text(answer, style = MaterialTheme.typography.bodyMedium)
        }
    }
}


// ─────────────────────────────────────────────
// AboutScreen.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.about

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("About") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Spacer(Modifier.height(24.dp))
            Icon(Icons.Default.ContactPhone, null, modifier = Modifier.size(80.dp),
                tint = MaterialTheme.colorScheme.primary)
            Text("AutoSave Contact", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Version 1.0", color = MaterialTheme.colorScheme.outline)
            Divider(modifier = Modifier.padding(vertical = 8.dp))
            Text("Automatically saves phone numbers from calls that are not in your contacts.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
