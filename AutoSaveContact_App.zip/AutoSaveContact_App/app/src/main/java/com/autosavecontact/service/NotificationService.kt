package com.autosavecontact.service

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class NotificationService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    fun showSavedNotification(phoneNumber: String) {
        val notification = NotificationCompat.Builder(this, "autosave_channel")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("New contact saved")
            .setContentText("Saved: $phoneNumber")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .build()

        getSystemService(NotificationManager::class.java)
            .notify(System.currentTimeMillis().toInt(), notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_NOT_STICKY
    }
}
