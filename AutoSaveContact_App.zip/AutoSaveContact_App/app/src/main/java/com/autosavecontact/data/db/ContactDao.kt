// ─────────────────────────────────────────────
// ContactDao.kt
// ─────────────────────────────────────────────
package com.autosavecontact.data.db

import androidx.room.*
import com.autosavecontact.data.model.Contact
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {

    @Query("SELECT * FROM table_contacts ORDER BY savedAt DESC")
    fun getAllContacts(): Flow<List<Contact>>

    @Query("SELECT * FROM table_contacts WHERE groupName = :groupName ORDER BY savedAt DESC")
    fun getContactsByGroup(groupName: String): Flow<List<Contact>>

    @Query("SELECT * FROM table_contacts WHERE phoneNumber = :number LIMIT 1")
    suspend fun getContactByNumber(number: String): Contact?

    @Query("""
        SELECT * FROM table_contacts 
        WHERE name LIKE '%' || :query || '%' 
           OR phoneNumber LIKE '%' || :query || '%'
        ORDER BY savedAt DESC
    """)
    fun searchContacts(query: String): Flow<List<Contact>>

    @Query("SELECT COUNT(*) FROM table_contacts")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(contact: Contact): Long

    @Update
    suspend fun update(contact: Contact)

    @Delete
    suspend fun delete(contact: Contact)

    @Query("DELETE FROM table_contacts")
    suspend fun deleteAll()
}


// ─────────────────────────────────────────────
// GroupDao.kt
// ─────────────────────────────────────────────
package com.autosavecontact.data.db

import androidx.room.*
import com.autosavecontact.data.model.Group
import kotlinx.coroutines.flow.Flow

@Dao
interface GroupDao {

    @Query("SELECT * FROM table_groups ORDER BY createdAt DESC")
    fun getAllGroups(): Flow<List<Group>>

    @Query("SELECT COUNT(*) FROM table_groups")
    suspend fun getCount(): Int

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(group: Group): Long

    @Delete
    suspend fun delete(group: Group)

    @Query("DELETE FROM table_groups WHERE groupName = :name")
    suspend fun deleteByName(name: String)
}
