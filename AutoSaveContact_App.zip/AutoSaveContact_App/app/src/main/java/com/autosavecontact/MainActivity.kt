// ─────────────────────────────────────────────
// MainActivity.kt
// ─────────────────────────────────────────────
package com.autosavecontact

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.autosavecontact.ui.about.AboutScreen
import com.autosavecontact.ui.contacts.ContactsScreen
import com.autosavecontact.ui.contacts.ContactsViewModel
import com.autosavecontact.ui.dashboard.DashboardScreen
import com.autosavecontact.ui.export.ExportScreen
import com.autosavecontact.ui.groups.GroupsScreen
import com.autosavecontact.ui.help.HelpScreen
import com.autosavecontact.ui.settings.SettingsScreen
import com.autosavecontact.ui.theme.AutoSaveContactTheme

// ── Navigation Routes ────────────────────────────────────────────────
object Routes {
    const val DASHBOARD  = "dashboard"
    const val CONTACTS   = "contacts"
    const val GROUPS     = "groups"
    const val EXPORT     = "export"
    const val SETTINGS   = "settings"
    const val HELP       = "help"
    const val ABOUT      = "about"
}

class MainActivity : ComponentActivity() {

    // Request all needed runtime permissions on launch
    private val permissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* handle results if needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestRequiredPermissions()

        setContent {
            AutoSaveContactTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // ✅ Goes straight to Dashboard — no login
                    val navController = rememberNavController()
                    val viewModel: ContactsViewModel = viewModel()
                    AppNavGraph(navController, viewModel)
                }
            }
        }
    }

    private fun requestRequiredPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
        )
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.S_V2) {
            permissions += Manifest.permission.READ_EXTERNAL_STORAGE
            permissions += Manifest.permission.WRITE_EXTERNAL_STORAGE
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        permissionsLauncher.launch(permissions.toTypedArray())
    }
}

// ── Navigation Graph ──────────────────────────────────────────────────
@Composable
fun AppNavGraph(
    navController: NavHostController,
    viewModel: ContactsViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Routes.DASHBOARD
    ) {
        composable(Routes.DASHBOARD) {
            DashboardScreen(
                viewModel = viewModel,
                onNavigate = { route -> navController.navigate(route) }
            )
        }
        composable(Routes.CONTACTS) {
            ContactsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.GROUPS) {
            GroupsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.EXPORT) {
            ExportScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.HELP) {
            HelpScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.ABOUT) {
            AboutScreen(onBack = { navController.popBackStack() })
        }
    }
}
