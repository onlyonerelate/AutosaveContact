// ─────────────────────────────────────────────
// ContactsViewModel.kt
// ─────────────────────────────────────────────
package com.autosavecontact.ui.contacts

import android.app.Application
import android.content.ContentValues
import android.provider.ContactsContract
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.autosavecontact.data.db.AppDatabase
import com.autosavecontact.data.model.Contact
import com.autosavecontact.data.model.Group
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ContactsViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val contactDao = db.contactDao()
    private val groupDao = db.groupDao()

    // ── Search query ──────────────────────────────────────────
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // ── Contacts (filtered by search) ─────────────────────────
    val contacts: StateFlow<List<Contact>> = _searchQuery
        .debounce(300)
        .flatMapLatest { query ->
            if (query.isBlank()) contactDao.getAllContacts()
            else contactDao.searchContacts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Groups ────────────────────────────────────────────────
    val groups: StateFlow<List<Group>> = groupDao.getAllGroups()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ── Actions ───────────────────────────────────────────────

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun deleteContact(contact: Contact) {
        viewModelScope.launch(Dispatchers.IO) {
            contactDao.delete(contact)
        }
    }

    fun updateContact(contact: Contact) {
        viewModelScope.launch(Dispatchers.IO) {
            contactDao.update(contact)
        }
    }

    fun addGroup(name: String) {
        if (name.length < 3) return
        viewModelScope.launch(Dispatchers.IO) {
            groupDao.insert(Group(groupName = name))
        }
    }

    fun deleteGroup(group: Group) {
        viewModelScope.launch(Dispatchers.IO) {
            groupDao.delete(group)
        }
    }

    /**
     * Assigns a contact to a group.
     */
    fun assignContactToGroup(contact: Contact, groupName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            contactDao.update(contact.copy(groupName = groupName))
        }
    }

    /**
     * Saves a contact from the local DB to the Android device Contacts book.
     */
    fun saveToDeviceContacts(contact: Contact) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ops = ArrayList<android.content.ContentProviderOperation>()

                ops.add(
                    android.content.ContentProviderOperation
                        .newInsert(ContactsContract.RawContacts.CONTENT_URI)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null)
                        .withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null)
                        .build()
                )

                // Name
                ops.add(
                    android.content.ContentProviderOperation
                        .newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME,
                            contact.name.ifBlank { contact.phoneNumber }
                        )
                        .build()
                )

                // Phone
                ops.add(
                    android.content.ContentProviderOperation
                        .newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(
                            ContactsContract.Data.MIMETYPE,
                            ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            contact.phoneNumber
                        )
                        .withValue(
                            ContactsContract.CommonDataKinds.Phone.TYPE,
                            ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                        )
                        .build()
                )

                getApplication<Application>().contentResolver.applyBatch(
                    ContactsContract.AUTHORITY, ops
                )

                Log.d("ContactsVM", "Saved ${contact.phoneNumber} to device contacts")
            } catch (e: Exception) {
                Log.e("ContactsVM", "Failed to save to device contacts", e)
            }
        }
    }

    /**
     * Exports contacts list to CSV string.
     */
    fun exportToCSV(contactsList: List<Contact>): String {
        val sb = StringBuilder()
        sb.appendLine("Name,Phone Number,Group,Call Type,Saved At")
        contactsList.forEach { c ->
            sb.appendLine("\"${c.name}\",\"${c.phoneNumber}\",\"${c.groupName}\",${c.callType},${c.savedAt}")
        }
        return sb.toString()
    }
}
