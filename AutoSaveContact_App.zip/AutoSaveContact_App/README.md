# AutoSave Contact — Recreated Android App

## What This Is
A full recreation of the **AutoSave Contact** APK, rebuilt from scratch in modern **Kotlin + Jetpack Compose**, targeting **Android 12+** (API 31+). The login/OTP screen has been **removed** — the app launches directly into the Dashboard.

---

## App Features (reverse-engineered from APK)

| Feature | Description |
|---|---|
| **Auto-Save Contacts** | Listens for incoming/outgoing calls and auto-saves new numbers |
| **Contact List** | Displays all auto-saved contacts with search |
| **Groups** | Organize contacts into named groups |
| **Export** | Export contacts or groups to CSV/VCF |
| **Download** | Download contacts from a remote backup |
| **Settings** | Notification, sync, and storage preferences |
| **Help / About** | In-app help and app info |

---

## Project Structure

```
AutoSaveContact/
├── app/
│   ├── src/main/
│   │   ├── AndroidManifest.xml
│   │   ├── java/com/autosavecontact/
│   │   │   ├── MainActivity.kt               ← Entry point (no login)
│   │   │   ├── ui/
│   │   │   │   ├── dashboard/DashboardScreen.kt
│   │   │   │   ├── contacts/ContactsScreen.kt
│   │   │   │   ├── contacts/ContactsViewModel.kt
│   │   │   │   ├── groups/GroupsScreen.kt
│   │   │   │   ├── export/ExportScreen.kt
│   │   │   │   ├── settings/SettingsScreen.kt
│   │   │   │   ├── about/AboutScreen.kt
│   │   │   │   └── help/HelpScreen.kt
│   │   │   ├── data/
│   │   │   │   ├── db/AppDatabase.kt
│   │   │   │   ├── db/ContactDao.kt
│   │   │   │   ├── db/GroupDao.kt
│   │   │   │   ├── model/Contact.kt
│   │   │   │   └── model/Group.kt
│   │   │   ├── receiver/
│   │   │   │   └── PhoneCallReceiver.kt
│   │   │   └── service/
│   │   │       └── NotificationService.kt
│   │   └── res/
│   │       └── values/strings.xml
│   └── build.gradle
└── build.gradle
```

---

## Setup Instructions

1. Open **Android Studio Hedgehog** or newer
2. Create a new Empty Compose project named `AutoSaveContact`
3. Replace files with those provided in this package
4. Add dependencies (see `build.gradle`)
5. Build & run on Android 12+ device or emulator

---

## Key Permissions Required
```xml
<uses-permission android:name="android.permission.READ_CONTACTS" />
<uses-permission android:name="android.permission.WRITE_CONTACTS" />
<uses-permission android:name="android.permission.READ_CALL_LOG" />
<uses-permission android:name="android.permission.READ_PHONE_STATE" />
<uses-permission android:name="android.permission.SEND_SMS" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-permission android:name="android.permission.INTERNET" />
```
